class dbObjects:
	""" ids for critical database objects. """
	SENSORS_ALL = 1
	USERS_SYSTEM = 0